-- ============================================================
-- LIMPIEZA COMPLETA DE LA BASE DE DATOS
-- ============================================================
-- Ejecutar ANTES de query1-query13 + seed_completo.sql
-- Elimina todas las tablas, funciones, triggers y tipos.
-- ============================================================

-- ── Eliminar tablas (orden por dependencias FK) ──────────────

DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS performance_metrics CASCADE;
DROP TABLE IF EXISTS sus_responses CASCADE;
DROP TABLE IF EXISTS time_measurements CASCADE;
DROP TABLE IF EXISTS task_evaluation_matches CASCADE;
DROP TABLE IF EXISTS statistical_analysis_results CASCADE;
DROP TABLE IF EXISTS statistical_analyses CASCADE;
DROP TABLE IF EXISTS experiment_sessions CASCADE;
DROP TABLE IF EXISTS summary_evaluations CASCADE;
DROP TABLE IF EXISTS summary_versions CASCADE;
DROP TABLE IF EXISTS ai_executions CASCADE;
DROP TABLE IF EXISTS reference_tasks CASCADE;
DROP TABLE IF EXISTS prompt_versions CASCADE;
DROP TABLE IF EXISTS resumenes_detalle CASCADE;
DROP TABLE IF EXISTS trabajos_resumen CASCADE;
DROP TABLE IF EXISTS resumenes CASCADE;
DROP TABLE IF EXISTS tareas CASCADE;
DROP TABLE IF EXISTS participantes CASCADE;
DROP TABLE IF EXISTS reuniones CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;
DROP TABLE IF EXISTS metricas_n8n CASCADE;

-- ── Eliminar funciones y triggers ────────────────────────────

DROP TRIGGER IF EXISTS trg_calcular_sus ON sus_responses CASCADE;
DROP FUNCTION IF EXISTS calcular_puntaje_sus() CASCADE;

DROP TRIGGER IF EXISTS trigger_update_data_hash ON statistical_analyses CASCADE;
DROP FUNCTION IF EXISTS generate_data_hash() CASCADE;

DROP FUNCTION IF EXISTS crear_reunion_con_participantes(jsonb) CASCADE;

-- ── Eliminar tipos enum ─────────────────────────────────────

DROP TYPE IF EXISTS user_role CASCADE;

-- ── Eliminar storage bucket si existe ────────────────────────

DELETE FROM storage.buckets WHERE id = 'grabaciones-reuniones';

-- ============================================================
-- LIMPIEZA COMPLETADA
-- Ahora ejecutar en orden:
--   1. query1.txt
--   2. query2.txt
--   3. query3.txt
--   4. query4.txt
--   5. query5_metricas.txt
--   6. query6_reuniones_participantes.sql
--   7. query7_resumenes_modulo.sql
--   8. query8_metricas_inferenciales.sql
--   9. query9_evaluacion_cientifica.sql
--  10. query10_establecer_admin.sql
--  11. query11_actualizar_password.sql
--  12. query12_persistencia_analisis.sql
--  13. query13_mejorar_rls_evaluacion.sql
--  14. seed_completo.sql
-- ============================================================

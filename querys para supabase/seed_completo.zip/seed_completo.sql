-- ============================================================
-- SEED COMPLETO PARA REUNIONESAUTO (ZOOM2)
-- ============================================================
-- Ejecutar DESPUÉS de todos los scripts query1-query12.
-- Contraseña para todos los usuarios: password123
-- ============================================================

-- ── 1. USUARIOS ─────────────────────────────────────────────

INSERT INTO usuarios (id, nombre, correo, password_hash, nivel_suscripcion, estado_suscripcion, rol) VALUES
('a0000000-0000-0000-0000-000000000001', 'Admin General',     'anthonygv268@gmail.com',       '$2b$12$uNfuUI5efGnBUqEUgv5p/eKUsho7MvsUGkzhTFHuIVKQQMQ1P/Nmu', 'enterprise', 'activo', 'ADMIN'),
('a0000000-0000-0000-0000-000000000002', 'Dra. Laura Medina',  'laura@zoom2.test',       '$2b$12$uNfuUI5efGnBUqEUgv5p/eKUsho7MvsUGkzhTFHuIVKQQMQ1P/Nmu', 'pro',        'activo', 'INVESTIGADOR'),
('a0000000-0000-0000-0000-000000000003', 'Carlos Ríos',        'carlos@zoom2.test',      '$2b$12$uNfuUI5efGnBUqEUgv5p/eKUsho7MvsUGkzhTFHuIVKQQMQ1P/Nmu', 'pro',        'activo', 'EVALUADOR'),
('a0000000-0000-0000-0000-000000000004', 'María López',        'maria@zoom2.test',       '$2b$12$uNfuUI5efGnBUqEUgv5p/eKUsho7MvsUGkzhTFHuIVKQQMQ1P/Nmu', 'basico',     'activo', 'USUARIO'),
('a0000000-0000-0000-0000-000000000005', 'Ing. Andrés Vega',   'andres@zoom2.test',      '$2b$12$uNfuUI5efGnBUqEUgv5p/eKUsho7MvsUGkzhTFHuIVKQQMQ1P/Nmu', 'pro',        'activo', 'INVESTIGADOR');


-- ── 2. REUNIONES ────────────────────────────────────────────

INSERT INTO reuniones (id, creador_id, tema, fecha_inicio, duracion_minutos, proveedor, estado, tipo) VALUES
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'Sprint Review — Módulo de Resúmenes IA',         '2025-06-15 09:00:00-05', 60, 'zoom', 'completada', 'virtual'),
('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', 'Revisión de Resultados Experimentales — Prompt v1.0', '2025-06-18 14:00:00-05', 45, 'zoom', 'completada', 'virtual'),
('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000001', 'Daily Standup — Equipo de Desarrollo',           '2025-06-20 08:30:00-05', 15, 'zoom', 'completada', 'virtual'),
('b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000002', 'Análisis Estadístico — Comparación de Prompts',   '2025-06-22 10:00:00-05', 90, 'zoom', 'completada', 'virtual'),
('b0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000001', 'Planificación Q3 — Objetivos de Investigación',   '2025-07-01 09:00:00-05', 120, 'zoom', 'programada', 'virtual'),
('b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000005', 'Workshop — Validación de Gold Standard',          '2025-06-25 11:00:00-05', 75, 'zoom', 'completada', 'virtual');


-- ── 3. PARTICIPANTES ────────────────────────────────────────

INSERT INTO participantes (reunion_id, usuario_id, correo, rol, estado_invitacion) VALUES
-- Reunión 1: Sprint Review
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', 'anthonygv268@gmail.com',       'organizador', 'aceptado'),
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000003', 'carlos@zoom2.test',      'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000004', 'maria@zoom2.test',       'participante', 'aceptado'),
-- Reunión 2: Revisión Experimentos
('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'organizador', 'aceptado'),
('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001', 'anthonygv268@gmail.com',       'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000005', 'andres@zoom2.test',      'participante', 'aceptado'),
-- Reunión 3: Daily Standup
('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000001', 'anthonygv268@gmail.com',       'organizador', 'aceptado'),
('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000005', 'andres@zoom2.test',      'participante', 'aceptado'),
-- Reunión 4: Análisis Estadístico
('b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'organizador', 'aceptado'),
('b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000005', 'andres@zoom2.test',      'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000003', 'carlos@zoom2.test',      'participante', 'aceptado'),
-- Reunión 5: Planificación Q3
('b0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000001', 'anthonygv268@gmail.com',       'organizador', 'enviado'),
('b0000000-0000-0000-0000-000000000005', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'participante', 'enviado'),
-- Reunión 6: Workshop Gold Standard
('b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000005', 'andres@zoom2.test',      'organizador', 'aceptado'),
('b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000002', 'laura@zoom2.test',       'participante', 'aceptado'),
('b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000003', 'carlos@zoom2.test',      'participante', 'aceptado');


-- ── 4. TAREAS ───────────────────────────────────────────────

INSERT INTO tareas (id, reunion_id, descripcion, asignado_a_correo, estado, fecha_vencimiento) VALUES
('c0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'Publicar resumen del sprint en Confluence',                     'maria@zoom2.test',   'completada',  '2025-06-17'),
('c0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 'Revisar métricas de calidad de resúmenes generados por IA',     'carlos@zoom2.test',  'completada',  '2025-06-18'),
('c0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000001', 'Preparar presentación de resultados para stakeholders',         'laura@zoom2.test',   'en_progreso', '2025-06-20'),
('c0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000002', 'Documentar hallazgos del experimento con prompt v1.0',          'laura@zoom2.test',   'completada',  '2025-06-20'),
('c0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000002', 'Configurar siguiente ronda de experimentos con prompt v1.1',    'andres@zoom2.test',  'pendiente',   '2025-06-25'),
('c0000000-0000-0000-0000-000000000006', 'b0000000-0000-0000-0000-000000000003', 'Actualizar backlog con tareas del standup',                      'anthonygv268@gmail.com',   'completada',  '2025-06-20'),
('c0000000-0000-0000-0000-000000000007', 'b0000000-0000-0000-0000-000000000004', 'Ejecutar análisis estadístico de fidelidad de resúmenes',       'laura@zoom2.test',   'completada',  '2025-06-24'),
('c0000000-0000-0000-0000-000000000008', 'b0000000-0000-0000-0000-000000000004', 'Generar reporte PDF con resultados del análisis',               'andres@zoom2.test',  'pendiente',   '2025-06-28'),
('c0000000-0000-0000-0000-000000000009', 'b0000000-0000-0000-0000-000000000006', 'Validar tareas gold standard con el equipo',                    'carlos@zoom2.test',  'completada',  '2025-06-26'),
('c0000000-0000-0000-0000-000000000010', 'b0000000-0000-0000-0000-000000000006', 'Definir criterios de evaluación para el cuestionario SUS',      'laura@zoom2.test',   'completada',  '2025-06-26');


-- ── 5. RESÚMENES ────────────────────────────────────────────

INSERT INTO resumenes (reunion_id, resumen) VALUES
('b0000000-0000-0000-0000-000000000001', 'Sprint review exitosa. Se completaron 8 de 10 historias de usuario. El módulo de resúmenes IA está en fase de testing. Se identificó un bug en la generación de resúmenes para reuniones > 60 min. Acción: Laura investigará el timeout del workflow de n8n.'),
('b0000000-0000-0000-0000-000000000002', 'Revisión de resultados del experimento con prompt v1.0. La fidelidad promedio fue 3.8/5. Los participantes notaron omisiones en acuerdos secundarios. Se decide avanzar con prompt v1.1 incorporando reglas de extracción de acuerdos.'),
('b0000000-0000-0000-0000-000000000003', 'Standup rápido. Andrés completó la integración con la API de Zoom. Laura trabajando en análisis estadístico. Pendiente: configurar entorno de staging.'),
('b0000000-0000-0000-0000-000000000004', 'Sesión de análisis estadístico. Se compararon prompts v1.0 vs v1.1 usando prueba t de Welch. Resultado: v1.1 muestra mejora estadísticamente significativa en claridad (p < 0.05). Se recomienda continuar con v1.1.'),
('b0000000-0000-0000-0000-000000000006', 'Workshop de validación gold standard. Se definieron 15 tareas de referencia para evaluar la extracción automática. Carlos validó 12 como gold standard. Pendiente: validar las 3 restantes con el equipo.');


-- ── 6. RESÚMENES DETALLE ────────────────────────────────────

INSERT INTO resumenes_detalle (reunion_id, resumen_ejecutivo, decisiones, riesgos, proximos_pasos) VALUES
('b0000000-0000-0000-0000-000000000001',
 'Sprint review del módulo de resúmenes IA. 80% de historias completadas. Bug detectado en timeouts.',
 '1) Priorizar fix de timeout para reuniones largas. 2) Mantener el ritmo de desarrollo actual.',
 'Riesgo de retraso en release si el bug de timeout no se resuelve antes del viernes.',
 '1) Laura investiga timeout (fecha límite: miércoles). 2) Andrés prepara hotfix. 3) Reunión de seguimiento el jueves.'),
('b0000000-0000-0000-0000-000000000004',
 'Análisis comparativo de prompts v1.0 vs v1.1. Mejora significativa en claridad.',
 '1) Adoptar prompt v1.1 como versión estándar. 2) Archivar v1.0 como histórico.',
 'Riesgo de overfitting del prompt a los datos de entrenamiento.',
 '1) Ejecutar segunda ronda de validación con nuevos datos. 2) Documentar cambios en prompt v1.1.');


-- ── 7. PROMPT VERSIONS ──────────────────────────────────────

INSERT INTO prompt_versions (id, nombre, version, contenido, objetivo, proveedor, modelo_recomendado, activo, creado_por) VALUES
('d0000000-0000-0000-0000-000000000001', 'resumen_reunion', '1.0',
 'Eres un asistente experto en reuniones corporativas. Genera un resumen ejecutivo de la siguiente reunión. Incluye: tema principal, participantes, acuerdos tomados, tareas asignadas y próximos pasos.',
 'Generar resúmenes precisos de reuniones para el equipo de gestión.',
 'openai', 'gpt-4', false, 'a0000000-0000-0000-0000-000000000002'),
('d0000000-0000-0000-0000-000000000002', 'resumen_reunion', '1.1',
 'Eres un asistente experto en reuniones corporativas. Genera un resumen ejecutivo de la siguiente reunión. Incluye: tema principal, participantes roles, acuerdos tomados (separados por categoría), tareas asignadas con responsable y fecha, riesgos identificados y próximos pasos con prioridad.',
 'Generar resúmenes más detallados con clasificación de acuerdos y priorización.',
 'openai', 'gpt-4', true, 'a0000000-0000-0000-0000-000000000002'),
('d0000000-0000-0000-0000-000000000003', 'extraccion_tareas', '1.0',
 'Analiza la transcripción de la reunión y extrae todas las tareas mencionadas. Para cada tarea indica: descripción, responsable (si se menciona), fecha límite (si se menciona) y nivel de prioridad.',
 'Extraer tareas accionables de reuniones de forma automática.',
 'openai', 'gpt-4', true, 'a0000000-0000-0000-0000-000000000005'),
('d0000000-0000-0000-0000-000000000004', 'clasificacion_sentimientos', '1.0',
 'Clasifica el sentimiento general de cada participante en la reunión como positivo, neutro o negativo. Proporciona evidencia textual para cada clasificación.',
 'Evaluar el clima de las reuniones para detección temprana de conflictos.',
 'anthropic', 'claude-3-sonnet', false, 'a0000000-0000-0000-0000-000000000002'),
('d0000000-0000-0000-0000-000000000005', 'resumen_reunion', '2.0',
 'Eres un analista senior de reuniones corporativas con 10 años de experiencia. Genera un resumen ejecutivo de alta calidad de la siguiente reunión. Estructura: (1) Resumen ejecutivo en 3-5 oraciones, (2) Decisiones clave con impacto estimado, (3) Tareas asignadas en formato tabla [Tarea | Responsable | Fecha | Prioridad], (4) Riesgos y mitigaciones, (5) Próximos pasos con owner y deadline.',
 'Generar resúmenes ejecutivos de nivel C-suite con estructura profesional.',
 'openai', 'gpt-4-turbo', true, 'a0000000-0000-0000-0000-000000000002');


-- ── 8. AI EXECUTIONS ────────────────────────────────────────

INSERT INTO ai_executions (id, reunion_id, prompt_version_id, proveedor, modelo, temperatura, tokens_entrada, tokens_salida, costo_estimado, tiempo_ms, estado, iniciado_por) VALUES
('e0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'openai', 'gpt-4',     0.3, 1250, 380, 0.0250, 3200, 'completado', 'a0000000-0000-0000-0000-000000000001'),
('e0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000002', 'openai', 'gpt-4',     0.3, 980,  420, 0.0220, 2800, 'completado', 'a0000000-0000-0000-0000-000000000002'),
('e0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 'd0000000-0000-0000-0000-000000000001', 'openai', 'gpt-4',     0.3, 450,  180, 0.0090, 1500, 'completado', 'a0000000-0000-0000-0000-000000000001'),
('e0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000004', 'd0000000-0000-0000-0000-000000000002', 'openai', 'gpt-4',     0.3, 2100, 650, 0.0420, 4500, 'completado', 'a0000000-0000-0000-0000-000000000002'),
('e0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000006', 'd0000000-0000-0000-0000-000000000003', 'openai', 'gpt-4',     0.3, 1800, 520, 0.0360, 3800, 'completado', 'a0000000-0000-0000-0000-000000000005');


-- ── 9. SUMMARY VERSIONS ─────────────────────────────────────

INSERT INTO summary_versions (reunion_id, ai_execution_id, version, origen, contenido, estado, es_version_actual, creado_por) VALUES
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 1, 'IA',
 'Sprint Review — Módulo de Resúmenes IA. Participantes: Admin, Laura, Carlos, María. Acuerdos: 1) Priorizar fix de timeout para reuniones >60min. 2) Mantener ritmo de desarrollo. Tareas: Laura investiga timeout (miércoles), Andrés prepara hotfix. Próximo paso: reunión de seguimiento jueves.',
 'APROBADO', true, 'a0000000-0000-0000-0000-000000000001'),
('b0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000002', 1, 'IA',
 'Revisión de Resultados Experimentales. Prompt v1.0: fidelidad 3.8/5. Hallazgos: omisiones en acuerdos secundarios. Decisión: avanzar con prompt v1.1 con reglas de extracción mejoradas. Riesgo: overfitting a datos de entrenamiento.',
 'APROBADO', true, 'a0000000-0000-0000-0000-000000000002'),
('b0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000004', 1, 'IA',
 'Análisis Estadístico — Comparación de Prompts. Prueba: t de Welch. Resultado: v1.1 muestra mejora significativa en claridad (p < 0.05). Recomendación: adoptar v1.1 como versión estándar.',
 'PENDIENTE_REVISION', true, 'a0000000-0000-0000-0000-000000000002');


-- ── 10. SUMMARY EVALUATIONS ─────────────────────────────────

INSERT INTO summary_evaluations (reunion_id, summary_version_id, evaluador_id, fidelidad, cobertura, claridad, coherencia, concision, utilidad, acuerdos_correctos, responsables_correctos, fechas_correctas, omisiones, afirmaciones_no_respaldadas, contradicciones, aprobado_sin_cambios, observaciones) VALUES
-- Evaluación del resumen 1 (Sprint Review) por Carlos
('b0000000-0000-0000-0000-000000000001', (SELECT id FROM summary_versions WHERE reunion_id = 'b0000000-0000-0000-0000-000000000001' AND version = 1),
 'a0000000-0000-0000-0000-000000000003', 4, 4, 5, 4, 4, 5, 4, 3, 3, 1, 0, 0, false, 'Buen resumen pero faltó mencionar la decisión de contratar un consultor externo.'),
-- Evaluación del resumen 1 por Laura
('b0000000-0000-0000-0000-000000000001', (SELECT id FROM summary_versions WHERE reunion_id = 'b0000000-0000-0000-0000-000000000001' AND version = 1),
 'a0000000-0000-0000-0000-000000000002', 5, 4, 4, 5, 4, 4, 4, 4, 3, 0, 1, 0, false, 'Preciso en acuerdos principales. Omisión menor en tareas secundarias.'),
-- Evaluación del resumen 2 (Revisión Experimentos) por Carlos
('b0000000-0000-0000-0000-000000000002', (SELECT id FROM summary_versions WHERE reunion_id = 'b0000000-0000-0000-0000-000000000002' AND version = 1),
 'a0000000-0000-0000-0000-000000000003', 4, 5, 5, 4, 5, 4, 5, 4, 4, 0, 0, 1, false, 'Excelente cobertura. Una contradicción menor sobre la fecha del próximo experimento.');


-- ── 11. REFERENCE TASKS (Gold Standard) ─────────────────────

INSERT INTO reference_tasks (id, reunion_id, descripcion, responsable_referencia, fecha_limite_referencia, creado_por, validado) VALUES
('f0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'Publicar resumen del sprint en Confluence',                    'María López',       '2025-06-17', 'a0000000-0000-0000-0000-000000000001', true),
('f0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 'Revisar métricas de calidad de resúmenes generados por IA',    'Carlos Ríos',       '2025-06-18', 'a0000000-0000-0000-0000-000000000001', true),
('f0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000001', 'Preparar presentación de resultados para stakeholders',        'Laura Medina',      '2025-06-20', 'a0000000-0000-0000-0000-000000000001', true),
('f0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000002', 'Documentar hallazgos del experimento con prompt v1.0',         'Laura Medina',      '2025-06-20', 'a0000000-0000-0000-0000-000000000002', true),
('f0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000001', 'Configurar entorno de staging para pruebas',                    'Ing. Andrés Vega',  '2025-06-22', 'a0000000-0000-0000-0000-000000000001', false),
('f0000000-0000-0000-0000-000000000006', 'b0000000-0000-0000-0000-000000000004', 'Ejecutar análisis estadístico de fidelidad',                    'Dra. Laura Medina',  '2025-06-24', 'a0000000-0000-0000-0000-000000000002', true),
('f0000000-0000-0000-0000-000000000007', 'b0000000-0000-0000-0000-000000000004', 'Generar reporte PDF con resultados',                             'Ing. Andrés Vega',  '2025-06-28', 'a0000000-0000-0000-0000-000000000002', false),
('f0000000-0000-0000-0000-000000000008', 'b0000000-0000-0000-0000-000000000006', 'Validar tareas gold standard con el equipo',                    'Carlos Ríos',       '2025-06-26', 'a0000000-0000-0000-0000-000000000005', true),
('f0000000-0000-0000-0000-000000000009', 'b0000000-0000-0000-0000-000000000006', 'Definir criterios de evaluación para el cuestionario SUS',      'Laura Medina',      '2025-06-26', 'a0000000-0000-0000-0000-000000000005', true),
('f0000000-0000-0000-0000-000000000010', 'b0000000-0000-0000-0000-000000000004', 'Documentar metodología del análisis estadístico de prompts',   'Andrés Vega',       '2025-06-28', 'a0000000-0000-0000-0000-000000000002', true),
('f0000000-0000-0000-0000-000000000011', 'b0000000-0000-0000-0000-000000000004', 'Configurar base de datos para siguiente ronda de experimentos', 'Andrés Vega',       '2025-06-30', 'a0000000-0000-0000-0000-000000000002', false);


-- ── 12. EXPERIMENT SESSIONS ─────────────────────────────────

INSERT INTO experiment_sessions (id, nombre, descripcion, investigador_id, condicion, prompt_version_id, modelo, estado, fecha_inicio, fecha_fin) VALUES
('10000000-0000-0000-0000-000000000001', 'Experimento Prompt v1.0 — Fidelidad',
 'Evaluar la fidelidad de resúmenes generados con prompt v1.0 vs transcripción original.',
 'a0000000-0000-0000-0000-000000000002', 'manual', 'd0000000-0000-0000-0000-000000000001', 'gpt-4',
 'COMPLETADO', '2025-06-15 10:00:00-05', '2025-06-22 16:00:00-05'),
('10000000-0000-0000-0000-000000000002', 'Experimento Prompt v1.1 — Fidelidad',
 'Evaluar la fidelidad de resúmenes generados con prompt v1.1 mejorado.',
 'a0000000-0000-0000-0000-000000000002', 'manual', 'd0000000-0000-0000-0000-000000000002', 'gpt-4',
 'EN_CURSO', '2025-06-23 09:00:00-05', NULL),
('10000000-0000-0000-0000-000000000003', 'Experimento Extracción de Tareas',
 'Evaluar la capacidad del sistema para extraer tareas de transcripciones.',
 'a0000000-0000-0000-0000-000000000005', 'zoom2_base', 'd0000000-0000-0000-0000-000000000003', 'gpt-4',
 'COMPLETADO', '2025-06-20 11:00:00-05', '2025-06-25 14:30:00-05'),
('10000000-0000-0000-0000-000000000004', 'Experimento SUS — Usabilidad',
 'Evaluar la usabilidad del sistema usando el cuestionario System Usability Scale.',
 'a0000000-0000-0000-0000-000000000002', 'manual', NULL, NULL,
 'PLANIFICADO', '2025-07-01 09:00:00-05', NULL),
('10000000-0000-0000-0000-000000000005', 'Experimento Prompt v2.0 — Comparativo',
 'Comparar prompt v2.0 (C-suite) contra v1.1 en reuniones ejecutivas.',
 'a0000000-0000-0000-0000-000000000002', 'zoom2_mejorado', 'd0000000-0000-0000-0000-000000000005', 'gpt-4-turbo',
 'PLANIFICADO', '2025-07-05 10:00:00-05', NULL);


-- ── 13. STATISTICAL ANALYSES ────────────────────────────────

INSERT INTO statistical_analyses (id, experiment_session_id, nombre, objetivo, variable_resultado, variable_grupo, diseno, prueba_solicitada, prueba_ejecutada, alpha, correccion_multiple, filtros, configuracion, estado, creado_por, fecha_ejecucion) VALUES
('20000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001',
 'Comparación v1.0 vs v1.1 — Fidelidad',
 'Determinar si el prompt v1.1 produce resúmenes con mayor fidelidad que v1.0.',
 'fidelidad', 'version_prompt', 'INDEPENDIENTE', 'welch_t_test', 'welch_t_test', 0.05, 'HOLM',
 '{"min_observations": 10}', '{"confidence_level": 0.95}',
 'COMPLETADO', 'a0000000-0000-0000-0000-000000000002', '2025-06-22 15:30:00-05'),
('20000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001',
 'Comparación v1.0 vs v1.1 — Claridad',
 'Determinar si el prompt v1.1 produce resúmenes con mayor claridad.',
 'claridad', 'version_prompt', 'INDEPENDIENTE', 'mann_whitney_u', 'mann_whitney_u', 0.05, 'HOLM',
 '{"min_observations": 10}', '{"confidence_level": 0.95}',
 'COMPLETADO', 'a0000000-0000-0000-0000-000000000002', '2025-06-22 15:45:00-05'),
('20000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003',
 'Extracción de Tareas — Precisión',
 'Medir la precisión de extracción de tareas del sistema.',
 'precision', 'condicion', 'INDEPENDIENTE', NULL, 'welch_t_test', 0.05, 'NONE',
 '{"metric": "precision"}', '{"bootstrap_iterations": 1000}',
 'COMPLETADO', 'a0000000-0000-0000-0000-000000000005', '2025-06-25 15:00:00-05'),
('20000000-0000-0000-0000-000000000004', NULL,
 'Análisis de Consistencia — Escala Likert',
 'Verificar la consistencia interna de la escala de evaluación de resúmenes.',
 'consistency_score', NULL, 'INDEPENDIENTE', 'cronbach_alpha', 'cronbach_alpha', 0.05, NULL,
 '{"items": ["fidelidad", "cobertura", "claridad", "coherencia", "concision", "utilidad"]}',
 '{}', 'PLANIFICADO', 'a0000000-0000-0000-0000-000000000002', NULL);


-- ── 14. STATISTICAL ANALYSIS RESULTS ────────────────────────

INSERT INTO statistical_analysis_results (analysis_id, resultado, descriptivos, supuestos, efecto, intervalos, advertencias, interpretacion) VALUES
('20000000-0000-0000-0000-000000000001',
 '{"statistic": 2.34, "p_value": 0.028, "df": 18.5, "significant": true}',
 '{"group_a": {"mean": 3.8, "std": 0.6, "n": 12, "min": 2.5, "max": 5.0, "q1": 3.3, "median": 3.8, "q3": 4.3},
   "group_b": {"mean": 4.3, "std": 0.5, "n": 12, "min": 3.0, "max": 5.0, "q1": 4.0, "median": 4.5, "q3": 4.8}}',
 '{"normality_a": true, "normality_b": true, "equal_variances": false}',
 '{"cohens_d": 0.91, "magnitude": "large"}',
 '{"ci_lower": 0.08, "ci_upper": 0.92}',
 '[]',
 'El prompt v1.1 produce resúmenes con fidelidad significativamente mayor que v1.0 (t=2.34, p=0.028). El tamaño del efecto es grande (d=0.91).'),
('20000000-0000-0000-0000-000000000002',
 '{"statistic": 2.89, "p_value": 0.012, "df": 20, "significant": true}',
 '{"group_a": {"mean": 3.5, "std": 0.7, "n": 12},
   "group_b": {"mean": 4.2, "std": 0.5, "n": 12}}',
 '{"normality_a": false, "normality_b": true, "equal_variances": false}',
 '{"rank_biserial": 0.68, "magnitude": "large"}',
 '{"ci_lower": 0.15, "ci_upper": 1.25}',
 '["Normalidad no verificada en grupo A, se usa prueba no paramétrica"]',
 'El prompt v1.1 produce resúmenes con claridad significativamente mayor (U=2.89, p=0.012).');


-- ── 15. SUS RESPONSES ───────────────────────────────────────

INSERT INTO sus_responses (experiment_session_id, usuario_id, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, observaciones) VALUES
('10000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000001', 4, 2, 5, 2, 4, 2, 4, 2, 5, 2, 'Interfaz intuitiva. El tiempo de carga podría mejorar.'),
('10000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000003', 5, 1, 5, 1, 4, 2, 5, 1, 4, 2, 'Muy fácil de usar. Las evaluaciones ciegas son un buen feature.'),
('10000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000004', 4, 3, 4, 3, 3, 3, 4, 3, 4, 3, 'Aceptable. Algunas funcionalidades no están claras.');


-- ── 16. TIME MEASUREMENTS ───────────────────────────────────

INSERT INTO time_measurements (experiment_session_id, reunion_id, participante_id, condicion, tiempo_elaboracion_segundos, tiempo_revision_segundos, tiempo_total_segundos, errores_detectados) VALUES
('10000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000003', 'manual', 180, 120, 300, 1),
('10000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000003', 'manual', 150, 100, 250, 0),
('10000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000004', 'a0000000-0000-0000-0000-000000000003', 'manual', 120, 90, 210, 0),
('10000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 'a0000000-0000-0000-0000-000000000004', 'zoom2_base', 90, 60, 150, 2),
('10000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000006', 'a0000000-0000-0000-0000-000000000004', 'zoom2_base', 100, 70, 170, 1);


-- ── 17. TASK EVALUATION MATCHES ─────────────────────────────

INSERT INTO task_evaluation_matches (reunion_id, ai_execution_id, reference_task_id, detected_task_id, resultado, similitud, validado_por, observaciones) VALUES
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'f0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', 'TP', 0.92, 'a0000000-0000-0000-0000-000000000003', 'Tarea detectada correctamente.'),
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'f0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000002', 'TP', 0.87, 'a0000000-0000-0000-0000-000000000003', 'Tarea detectada con ligera variación en redacción.'),
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'f0000000-0000-0000-0000-000000000003', NULL, 'FN', NULL, 'a0000000-0000-0000-0000-000000000003', 'Tarea no detectada por el sistema.'),
('b0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000002', 'f0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000004', 'TP', 0.95, 'a0000000-0000-0000-0000-000000000003', 'Coincidencia casi perfecta.');


-- ── 18. PERFORMANCE METRICS ─────────────────────────────────

INSERT INTO performance_metrics (reunion_id, ai_execution_id, componente, operacion, duracion_ms, exitoso, codigo_estado) VALUES
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'n8n', 'webhook_receive', 45, true, '200'),
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'openai', 'chat_completion', 3200, true, '200'),
('b0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'supabase', 'insert_summary', 120, true, '200'),
('b0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000002', 'n8n', 'webhook_receive', 38, true, '200'),
('b0000000-0000-0000-0000-000000000002', 'e0000000-0000-0000-0000-000000000002', 'openai', 'chat_completion', 2800, true, '200'),
('b0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000004', 'openai', 'chat_completion', 4500, true, '200'),
('b0000000-0000-0000-0000-000000000004', 'e0000000-0000-0000-0000-000000000004', 'n8n', 'transcription', 8500, true, '200');


-- ── 19. METRICAS N8N ────────────────────────────────────────

INSERT INTO metricas_n8n (endpoint, tiempo_respuesta, estado, fecha, codigo_estado, tamano_respuesta, outcome, is_terminal, data_source) VALUES
('/api/v1/research/analyses', 0.12, 'success', NOW() - INTERVAL '2 days', 200, 1540, 'success', true, 'production'),
('/experiments/sessions',     0.08, 'success', NOW() - INTERVAL '2 days', 200, 2100, 'success', true, 'production'),
('/evaluations/summaries',    0.10, 'success', NOW() - INTERVAL '2 days', 200, 890,  'success', true, 'production'),
('/prompts',                  0.05, 'success', NOW() - INTERVAL '1 day',  200, 3200, 'success', true, 'production'),
('/auth/login',               0.15, 'success', NOW() - INTERVAL '1 day',  200, 450,  'success', true, 'production'),
('/auth/me',                  0.03, 'success', NOW() - INTERVAL '1 day',  200, 280,  'success', true, 'production'),
('/reports',                  0.20, 'success', NOW() - INTERVAL '12 hours', 200, 1800, 'success', true, 'production');


-- ============================================================
-- RESUMEN DEL SEED
-- ============================================================
-- 5 usuarios  (1 admin, 2 investigadores, 1 evaluador, 1 usuario)
-- 6 reuniones (4 completadas, 1 programada, 1 sin estado explícito)
-- 18 participantes
-- 10 tareas
-- 5 resúmenes
-- 2 resúmenes detalle
-- 5 prompts (v1.0, v1.1, v2.0, extracción, sentimientos)
-- 5 ejecuciones IA
-- 3 summary versions
-- 3 evaluaciones de resúmenes
-- 8 reference tasks (gold standard)
-- 5 sesiones experimentales
-- 4 análisis estadísticos
-- 2 resultados de análisis
-- 3 respuestas SUS
-- 5 mediciones de tiempo
-- 4 task evaluation matches
-- 7 métricas de performance
-- 7 métricas n8n
-- ============================================================
